test_data = uint8([1, 2, 3, 4, 5]);
hash_result = DataHash(test_data, struct('Method', 'SHA-256', 'Format', 'hex'))
